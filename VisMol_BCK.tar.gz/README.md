# VisMol
Another version of EasyMol, using modern OpenGL with shaders

To test run the command:
    python VisMol 1l2y.pdb

Once the window is opened, press "l" to load the data and then use whichever of the next commands:

b --> Turn on/off the ball-stick representation
d --> Turn on/off the dots representation
c --> Turn on/off the crystal representation
r --> Turn on/off the ribbon representation (crashes when there is no c-alphas)
s --> Turn on/off the spheres representation
esc --> Quits the program

